#include "main.h"

int main() {
	//Initialization
	
	while (1) {
		//Run stuff continuously here
	}
}
